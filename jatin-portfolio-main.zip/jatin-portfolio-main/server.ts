import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { DatabaseSync } from 'node:sqlite';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize SQLite database
const dbPath = path.join(__dirname, 'database.sqlite');
const db = new DatabaseSync(dbPath);

// Initialize Tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    passwordHash TEXT NOT NULL,
    name TEXT NOT NULL,
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    subtitle TEXT NOT NULL,
    description TEXT NOT NULL,
    category TEXT NOT NULL,
    technologies TEXT NOT NULL,
    imageUrl TEXT,
    liveUrl TEXT,
    githubUrl TEXT,
    featured INTEGER DEFAULT 0,
    sortOrder INTEGER DEFAULT 0,
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS services (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    summary TEXT NOT NULL,
    description TEXT NOT NULL,
    deliverables TEXT NOT NULL,
    sortOrder INTEGER DEFAULT 0,
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS inquiries (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    subject TEXT NOT NULL,
    message TEXT NOT NULL,
    status TEXT DEFAULT 'unread',
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS site_settings (
    id TEXT PRIMARY KEY,
    key TEXT UNIQUE NOT NULL,
    value TEXT NOT NULL,
    updatedAt TEXT NOT NULL
  );
`);

// Seed Default Data if empty (zero projects)
async function seedDatabase() {
  const userCheck = db.prepare('SELECT COUNT(*) as count FROM users').get() as { count: number };
  if (userCheck.count === 0) {
    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync('JatinSecure2026!', salt);
    const now = new Date().toISOString();

    db.prepare(`
      INSERT INTO users (id, email, passwordHash, name, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run('user-admin-1', 'userjatin2007@gmail.com', passwordHash, 'Jatin Mehra', now, now);

    // Clear and seed the 5 exact services
    db.prepare('DELETE FROM services').run();

    const services = [
      {
        id: 'srv-1',
        title: 'Website Development',
        slug: 'website-development',
        summary: '',
        description: 'I build websites for businesses and personal brands. They load fast, work well on phones and are easy to find on Google. Usually built with: React.',
        deliverables: '',
        sortOrder: 1,
      },
      {
        id: 'srv-2',
        title: 'Web Applications',
        slug: 'web-applications',
        summary: '',
        description: 'I build web apps like dashboards, booking systems and internal tools. I handle the frontend, backend and database myself. Usually built with: React, Node.js, TypeScript, PostgreSQL.',
        deliverables: '',
        sortOrder: 2,
      },
      {
        id: 'srv-3',
        title: 'AI Chatbots & Assistants',
        slug: 'ai-chatbots-assistants',
        summary: '',
        description: 'I build chatbots that answer customer questions from your own documents. They can live on your website or inside your internal tools. Usually built with: Node.js, Gemini API.',
        deliverables: '',
        sortOrder: 3,
      },
      {
        id: 'srv-4',
        title: 'Automation & Workflows',
        slug: 'automation-workflows',
        summary: '',
        description: 'I automate repetitive work like data entry, syncing tools and sending notifications. Less manual work, fewer mistakes. Usually built with: Node.js, TypeScript.',
        deliverables: '',
        sortOrder: 4,
      },
      {
        id: 'srv-5',
        title: 'Custom Software Solutions',
        slug: 'custom-software-solutions',
        summary: '',
        description: "If your idea doesn't fit the options above, tell me the problem. I'll tell you honestly whether I can build it. Usually built with: React, Node.js, PostgreSQL.",
        deliverables: '',
        sortOrder: 5,
      },
    ];

    const insertService = db.prepare(`
      INSERT INTO services (id, title, slug, summary, description, deliverables, sortOrder, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const s of services) {
      insertService.run(s.id, s.title, s.slug, s.summary, s.description, s.deliverables, s.sortOrder, now, now);
    }
  }

  // Clear any pre-existing projects so it starts empty as requested
  db.prepare('DELETE FROM projects').run();
}

seedDatabase();

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'jatin_mehra_secure_jwt_secret_2026';

app.use(cors());
app.use(express.json({ limit: '10mb' }));

interface AuthRequest extends Request {
  user?: { id: string; email: string; name: string };
}

const authenticateToken = (req: AuthRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user as { id: string; email: string; name: string };
    next();
  });
};

// API Routes
app.post('/api/auth/login', (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email) as any;
    if (!user || !bcrypt.compareSync(password, user.passwordHash)) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    const token = jwt.sign({ id: user.id, email: user.email, name: user.name }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: { id: user.id, email: user.email, name: user.name } });
  } catch (error) {
    res.status(500).json({ error: 'Login error' });
  }
});

app.get('/api/auth/me', authenticateToken, (req: AuthRequest, res: Response) => {
  const user = db.prepare('SELECT id, email, name FROM users WHERE id = ?').get(req.user?.id || '') as any;
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ user });
});

app.get('/api/projects', (req: Request, res: Response) => {
  const projects = db.prepare('SELECT * FROM projects ORDER BY sortOrder ASC').all();
  res.json(projects.map((p: any) => ({ ...p, featured: Boolean(p.featured) })));
});

app.post('/api/projects', authenticateToken, (req: Request, res: Response) => {
  const { title, slug, subtitle, description, category, technologies, liveUrl, githubUrl, featured, sortOrder } = req.body;
  const id = `proj-${Date.now()}`;
  const now = new Date().toISOString();
  db.prepare(`
    INSERT INTO projects (id, title, slug, subtitle, description, category, technologies, liveUrl, githubUrl, featured, sortOrder, createdAt, updatedAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(id, title, slug, subtitle || '', description, category, technologies || '', liveUrl || null, githubUrl || null, featured ? 1 : 0, Number(sortOrder) || 0, now, now);
  res.status(201).json(db.prepare('SELECT * FROM projects WHERE id = ?').get(id));
});

app.put('/api/projects/:id', authenticateToken, (req: Request, res: Response) => {
  const { title, slug, subtitle, description, category, technologies, liveUrl, githubUrl, featured, sortOrder } = req.body;
  const now = new Date().toISOString();
  db.prepare(`
    UPDATE projects SET title = ?, slug = ?, subtitle = ?, description = ?, category = ?, technologies = ?, liveUrl = ?, githubUrl = ?, featured = ?, sortOrder = ?, updatedAt = ?
    WHERE id = ?
  `).run(title, slug, subtitle, description, category, technologies, liveUrl, githubUrl, featured ? 1 : 0, Number(sortOrder) || 0, now, req.params.id);
  res.json(db.prepare('SELECT * FROM projects WHERE id = ?').get(req.params.id));
});

app.delete('/api/projects/:id', authenticateToken, (req: Request, res: Response) => {
  db.prepare('DELETE FROM projects WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

app.get('/api/services', (req: Request, res: Response) => {
  res.json(db.prepare('SELECT * FROM services ORDER BY sortOrder ASC').all());
});

app.get('/api/inquiries', authenticateToken, (req: Request, res: Response) => {
  res.json(db.prepare('SELECT * FROM inquiries ORDER BY createdAt DESC').all());
});

app.post('/api/inquiries', (req: Request, res: Response) => {
  const { name, email, subject, message } = req.body;
  if (!name || !email || !message) return res.status(400).json({ error: 'Required fields missing' });
  const id = `inq-${Date.now()}`;
  const now = new Date().toISOString();
  db.prepare(`
    INSERT INTO inquiries (id, name, email, subject, message, status, createdAt, updatedAt)
    VALUES (?, ?, ?, ?, ?, 'unread', ?, ?)
  `).run(id, name, email, subject || 'Inquiry', message, now, now);
  res.status(201).json({ success: true });
});

app.delete('/api/inquiries/:id', authenticateToken, (req: Request, res: Response) => {
  db.prepare('DELETE FROM inquiries WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

if (process.env.NODE_ENV !== 'production') {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({ server: { middlewareMode: true }, appType: 'spa' });
  app.use(vite.middlewares);
} else {
  app.use(express.static(path.join(__dirname, 'dist')));
  app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'dist', 'index.html')));
}

const server = app.listen(Number(PORT), '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
}).on('error', (err: any) => {
  if (err.code === 'EADDRINUSE') {
    const fallback = Number(PORT) + 1;
    app.listen(fallback, '0.0.0.0', () => console.log(`Server running on port ${fallback}`));
  }
});
