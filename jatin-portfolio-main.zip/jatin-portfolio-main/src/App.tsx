/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Mail, Menu, X, Lock, Trash2, Edit, Plus, CheckCircle2 } from 'lucide-react';

interface Project {
  id: string;
  title: string;
  slug: string;
  subtitle: string;
  description: string;
  category: string;
  technologies: string;
  liveUrl?: string;
  githubUrl?: string;
  featured: boolean;
  sortOrder: number;
}

interface Service {
  id: string;
  title: string;
  slug: string;
  summary: string;
  description: string;
  deliverables: string;
  sortOrder: number;
}

interface Inquiry {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  status: string;
  createdAt: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'services' | 'projects' | 'about' | 'contact' | 'admin' | 'privacy' | 'terms'>('home');
  const [projects, setProjects] = useState<Project[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Admin state
  const [authToken, setAuthToken] = useState<string>(localStorage.getItem('jatin_admin_token') || '');
  const [adminUser, setAdminUser] = useState<any>(null);
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminError, setAdminError] = useState('');
  const [adminView, setAdminView] = useState<'projects' | 'inquiries'>('projects');

  // Modal / Form states
  const [contactForm, setContactForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [contactStatus, setContactStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [contactErrorMessage, setContactErrorMessage] = useState('');

  // CRUD Editing states for Admin
  const [editingProject, setEditingProject] = useState<Partial<Project> | null>(null);

  useEffect(() => {
    fetchPublicData();
    if (authToken) {
      verifyAdminToken(authToken);
    }
    const handleHash = () => {
      const hash = window.location.hash.replace('#', '');
      if (['home', 'services', 'projects', 'about', 'contact', 'admin', 'privacy', 'terms'].includes(hash)) {
        setActiveTab(hash as any);
      }
    };
    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, [authToken]);

  const fetchPublicData = async () => {
    try {
      const [projRes, servRes] = await Promise.all([
        fetch('/api/projects'),
        fetch('/api/services')
      ]);
      if (projRes.ok) setProjects(await projRes.json());
      if (servRes.ok) setServices(await servRes.json());
    } catch (err) {
      console.error('Failed to load public data', err);
    }
  };

  const verifyAdminToken = async (token: string) => {
    try {
      const res = await fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setAdminUser(data.user);
        fetchAdminInquiries(token);
      } else {
        handleLogout();
      }
    } catch {
      handleLogout();
    }
  };

  const fetchAdminInquiries = async (token: string) => {
    try {
      const res = await fetch('/api/inquiries', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) setInquiries(await res.json());
    } catch (err) {
      console.error('Failed to fetch inquiries', err);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdminError('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: adminEmail, password: adminPassword })
      });
      const data = await res.json();
      if (res.ok) {
        setAuthToken(data.token);
        localStorage.setItem('jatin_admin_token', data.token);
        setAdminUser(data.user);
        fetchAdminInquiries(data.token);
      } else {
        setAdminError(data.error || 'Login failed');
      }
    } catch {
      setAdminError('Network error during login');
    }
  };

  const handleLogout = () => {
    setAuthToken('');
    setAdminUser(null);
    localStorage.removeItem('jatin_admin_token');
  };

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setContactStatus('submitting');
    setContactErrorMessage('');
    try {
      const res = await fetch('/api/inquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(contactForm)
      });
      if (res.ok) {
        setContactStatus('success');
        setContactForm({ name: '', email: '', subject: '', message: '' });
      } else {
        setContactStatus('error');
        setContactErrorMessage('Failed to send message');
      }
    } catch {
      setContactStatus('error');
      setContactErrorMessage('Network error');
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F3ED] text-[#1C1B18] font-['Inter',sans-serif] antialiased flex flex-col justify-between selection:bg-[#1C1B18] selection:text-[#F4F3ED]">
      
      {/* Header */}
      <header className="sticky top-0 z-40 bg-[#F4F3ED]/95 backdrop-blur-sm border-b border-[#E5E3D8]">
        <div className="max-w-3xl mx-auto px-6 h-20 flex items-center justify-between">
          <button 
            onClick={() => setActiveTab('home')} 
            className="text-base font-medium tracking-tight text-[#1C1B18] text-left hover:opacity-70 transition-opacity"
          >
            Jatin Mehra
          </button>

          <nav className="hidden sm:flex items-center gap-8 text-sm text-[#5C5A53]">
            <button onClick={() => setActiveTab('home')} className={`hover:text-[#1C1B18] transition-colors ${activeTab === 'home' ? 'text-[#1C1B18] font-medium underline underline-offset-4' : ''}`}>
              Home
            </button>
            <button onClick={() => setActiveTab('services')} className={`hover:text-[#1C1B18] transition-colors ${activeTab === 'services' ? 'text-[#1C1B18] font-medium underline underline-offset-4' : ''}`}>
              Services
            </button>
            <button onClick={() => setActiveTab('projects')} className={`hover:text-[#1C1B18] transition-colors ${activeTab === 'projects' ? 'text-[#1C1B18] font-medium underline underline-offset-4' : ''}`}>
              Projects
            </button>
            <button onClick={() => setActiveTab('about')} className={`hover:text-[#1C1B18] transition-colors ${activeTab === 'about' ? 'text-[#1C1B18] font-medium underline underline-offset-4' : ''}`}>
              About
            </button>
            <button onClick={() => setActiveTab('contact')} className={`hover:text-[#1C1B18] transition-colors ${activeTab === 'contact' ? 'text-[#1C1B18] font-medium underline underline-offset-4' : ''}`}>
              Contact
            </button>
          </nav>

          <div className="flex items-center gap-4">
            <button 
              onClick={() => setActiveTab('contact')} 
              className="text-sm text-[#1C1B18] hover:text-[#A03822] transition-colors font-medium"
            >
              Contact
            </button>
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)} 
              className="sm:hidden p-1 text-[#5C5A53] hover:text-[#1C1B18]"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Nav Drawer */}
        {mobileMenuOpen && (
          <div className="sm:hidden border-b border-[#E5E3D8] bg-[#F4F3ED] px-6 py-5 flex flex-col gap-4 text-sm text-[#5C5A53]">
            <button onClick={() => { setActiveTab('home'); setMobileMenuOpen(false); }} className="text-left text-[#1C1B18]">Home</button>
            <button onClick={() => { setActiveTab('services'); setMobileMenuOpen(false); }} className="text-left text-[#1C1B18]">Services</button>
            <button onClick={() => { setActiveTab('projects'); setMobileMenuOpen(false); }} className="text-left text-[#1C1B18]">Projects</button>
            <button onClick={() => { setActiveTab('about'); setMobileMenuOpen(false); }} className="text-left text-[#1C1B18]">About</button>
            <button onClick={() => { setActiveTab('contact'); setMobileMenuOpen(false); }} className="text-left text-[#1C1B18]">Contact</button>
          </div>
        )}
      </header>

      {/* Main Content Area */}
      <main className="flex-grow">

        {/* HOME PAGE */}
        {activeTab === 'home' && (
          <div>
            {/* Hero Section */}
            <section className="max-w-3xl mx-auto px-6 pt-24 pb-20 sm:pt-32 sm:pb-28">
              <div className="space-y-6">
                <p className="text-sm text-[#5C5A53]">
                  Independent software developer based in India.
                </p>
                <h1 className="text-3xl sm:text-5xl font-['EB_Garamond',serif] font-normal tracking-tight text-[#1C1B18] leading-[1.25]">
                  I build websites and web apps for small businesses and startups.
                </h1>
                <p className="text-base sm:text-lg text-[#5C5A53] leading-relaxed max-w-2xl font-light">
                  You talk to me directly. I design it, build it and put it live.
                </p>
                <div className="pt-4 flex items-center">
                  <button 
                    onClick={() => setActiveTab('contact')}
                    className="inline-flex items-center text-sm font-medium text-[#1C1B18] bg-[#E5E3D8] hover:bg-[#DCDAD0] px-5 py-3 rounded-md transition-colors"
                  >
                    Get in touch
                  </button>
                </div>
              </div>
            </section>

            {/* Projects Section (Option B since list is empty) */}
            <section className="border-t border-[#E5E3D8] py-20">
              <div className="max-w-3xl mx-auto px-6 space-y-4">
                <h2 className="text-2xl font-['EB_Garamond',serif] text-[#1C1B18]">Projects</h2>
                <p className="text-sm text-[#5C5A53] leading-relaxed">
                  I'm adding recent work here soon. Email me and I'll share relevant examples.
                </p>
              </div>
            </section>

            {/* Services Section */}
            <section className="border-t border-[#E5E3D8] py-20">
              <div className="max-w-3xl mx-auto px-6 space-y-12">
                <div>
                  <h2 className="text-2xl font-['EB_Garamond',serif] text-[#1C1B18]">Services</h2>
                </div>

                <div className="space-y-12">
                  <div className="space-y-2">
                    <h3 className="text-lg font-['EB_Garamond',serif] font-semibold text-[#1C1B18]">Website Development</h3>
                    <p className="text-sm text-[#5C5A53] leading-relaxed">
                      I build websites for businesses and personal brands. They load fast, work well on phones and are easy to find on Google. Usually built with: React.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-lg font-['EB_Garamond',serif] font-semibold text-[#1C1B18]">Web Applications</h3>
                    <p className="text-sm text-[#5C5A53] leading-relaxed">
                      I build web apps like dashboards, booking systems and internal tools. I handle the frontend, backend and database myself. Usually built with: React, Node.js, TypeScript, PostgreSQL.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-lg font-['EB_Garamond',serif] font-semibold text-[#1C1B18]">AI Chatbots & Assistants</h3>
                    <p className="text-sm text-[#5C5A53] leading-relaxed">
                      I build chatbots that answer customer questions from your own documents. They can live on your website or inside your internal tools. Usually built with: Node.js, Gemini API.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-lg font-['EB_Garamond',serif] font-semibold text-[#1C1B18]">Automation & Workflows</h3>
                    <p className="text-sm text-[#5C5A53] leading-relaxed">
                      I automate repetitive work like data entry, syncing tools and sending notifications. Less manual work, fewer mistakes. Usually built with: Node.js, TypeScript.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-lg font-['EB_Garamond',serif] font-semibold text-[#1C1B18]">Custom Software Solutions</h3>
                    <p className="text-sm text-[#5C5A53] leading-relaxed">
                      If your idea doesn't fit the options above, tell me the problem. I'll tell you honestly whether I can build it. Usually built with: React, Node.js, PostgreSQL.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* About Section */}
            <section className="border-t border-[#E5E3D8] py-20">
              <div className="max-w-3xl mx-auto px-6 space-y-6">
                <h2 className="text-2xl font-['EB_Garamond',serif] text-[#1C1B18]">About</h2>
                <div className="space-y-4 text-sm text-[#5C5A53] leading-relaxed max-w-2xl">
                  <p className="text-base text-[#1C1B18]">
                    I'm Jatin, a web developer from India. I build websites and small web apps for people who want something that works and looks good. You talk to me directly, not a team.
                  </p>
                  <div>
                    <button onClick={() => setActiveTab('contact')} className="text-xs font-medium text-[#1C1B18] underline underline-offset-4">Get in touch &rarr;</button>
                  </div>
                </div>
              </div>
            </section>
          </div>
        )}

        {/* SERVICES PAGE */}
        {activeTab === 'services' && (
          <div className="max-w-3xl mx-auto px-6 py-20 space-y-12">
            <div>
              <h1 className="text-3xl font-['EB_Garamond',serif] font-normal text-[#1C1B18]">Services</h1>
            </div>
            <div className="space-y-12">
              <div className="space-y-2 border-b border-[#E5E3D8] pb-12">
                <h2 className="text-xl font-['EB_Garamond',serif] font-semibold text-[#1C1B18]">Website Development</h2>
                <p className="text-sm text-[#5C5A53] leading-relaxed">
                  I build websites for businesses and personal brands. They load fast, work well on phones and are easy to find on Google. Usually built with: React.
                </p>
              </div>

              <div className="space-y-2 border-b border-[#E5E3D8] pb-12">
                <h2 className="text-xl font-['EB_Garamond',serif] font-semibold text-[#1C1B18]">Web Applications</h2>
                <p className="text-sm text-[#5C5A53] leading-relaxed">
                  I build web apps like dashboards, booking systems and internal tools. I handle the frontend, backend and database myself. Usually built with: React, Node.js, TypeScript, PostgreSQL.
                </p>
              </div>

              <div className="space-y-2 border-b border-[#E5E3D8] pb-12">
                <h2 className="text-xl font-['EB_Garamond',serif] font-semibold text-[#1C1B18]">AI Chatbots & Assistants</h2>
                <p className="text-sm text-[#5C5A53] leading-relaxed">
                  I build chatbots that answer customer questions from your own documents. They can live on your website or inside your internal tools. Usually built with: Node.js, Gemini API.
                </p>
              </div>

              <div className="space-y-2 border-b border-[#E5E3D8] pb-12">
                <h2 className="text-xl font-['EB_Garamond',serif] font-semibold text-[#1C1B18]">Automation & Workflows</h2>
                <p className="text-sm text-[#5C5A53] leading-relaxed">
                  I automate repetitive work like data entry, syncing tools and sending notifications. Less manual work, fewer mistakes. Usually built with: Node.js, TypeScript.
                </p>
              </div>

              <div className="space-y-2 pb-12">
                <h2 className="text-xl font-['EB_Garamond',serif] font-semibold text-[#1C1B18]">Custom Software Solutions</h2>
                <p className="text-sm text-[#5C5A53] leading-relaxed">
                  If your idea doesn't fit the options above, tell me the problem. I'll tell you honestly whether I can build it. Usually built with: React, Node.js, PostgreSQL.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* PROJECTS PAGE */}
        {activeTab === 'projects' && (
          <div className="max-w-3xl mx-auto px-6 py-20 space-y-4">
            <h1 className="text-3xl font-['EB_Garamond',serif] font-normal text-[#1C1B18]">Projects</h1>
            <p className="text-sm text-[#5C5A53] leading-relaxed">
              I'm adding recent work here soon. Email me and I'll share relevant examples.
            </p>
          </div>
        )}

        {/* ABOUT PAGE */}
        {activeTab === 'about' && (
          <div className="max-w-3xl mx-auto px-6 py-20 space-y-8 text-sm text-[#5C5A53] leading-relaxed">
            <div>
              <h1 className="text-3xl font-['EB_Garamond',serif] font-normal text-[#1C1B18] mb-2">About</h1>
            </div>
            <div className="space-y-4 max-w-2xl text-base text-[#1C1B18]">
              <p>
                I'm Jatin, a web developer from India. I build websites and small web apps for people who want something that works and looks good. You talk to me directly, not a team.
              </p>
            </div>
          </div>
        )}

        {/* CONTACT PAGE */}
        {activeTab === 'contact' && (
          <div className="max-w-3xl mx-auto px-6 py-20 space-y-10">
            <div>
              <h1 className="text-3xl font-['EB_Garamond',serif] font-normal text-[#1C1B18]">Contact</h1>
            </div>
            <div className="space-y-6 max-w-lg">
              <p className="text-sm text-[#5C5A53]">Send a message and I'll get back to you shortly.</p>
              {contactStatus === 'success' ? (
                <div className="p-4 rounded bg-[#E5E3D8] text-xs text-[#1C1B18] space-y-2">
                  <div className="font-medium">Message sent successfully!</div>
                  <button onClick={() => setActiveTab('contact')} className="mt-2 text-xs underline font-medium">Send another</button>
                </div>
              ) : (
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  {contactStatus === 'error' && (
                    <div className="p-3 rounded bg-red-100 text-red-800 text-xs">{contactErrorMessage}</div>
                  )}
                  <div className="space-y-1">
                    <label className="text-xs text-[#5C5A53]">Your Name</label>
                    <input 
                      type="text" 
                      required 
                      placeholder="Alex Morgan" 
                      value={contactForm.name} 
                      onChange={e => setContactForm({ ...contactForm, name: e.target.value })}
                      className="w-full px-3 py-2 rounded bg-white border border-[#E5E3D8] text-sm text-[#1C1B18]"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs text-[#5C5A53]">Email Address</label>
                    <input 
                      type="email" 
                      required 
                      placeholder="alex@company.com" 
                      value={contactForm.email} 
                      onChange={e => setContactForm({ ...contactForm, email: e.target.value })}
                      className="w-full px-3 py-2 rounded bg-white border border-[#E5E3D8] text-sm text-[#1C1B18]"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs text-[#5C5A53]">Subject</label>
                    <input 
                      type="text" 
                      required 
                      placeholder="Project Inquiry" 
                      value={contactForm.subject} 
                      onChange={e => setContactForm({ ...contactForm, subject: e.target.value })}
                      className="w-full px-3 py-2 rounded bg-white border border-[#E5E3D8] text-sm text-[#1C1B18]"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs text-[#5C5A53]">Message</label>
                    <textarea 
                      required 
                      rows={4} 
                      placeholder="Tell me about your project..." 
                      value={contactForm.message} 
                      onChange={e => setContactForm({ ...contactForm, message: e.target.value })}
                      className="w-full px-3 py-2 rounded bg-white border border-[#E5E3D8] text-sm text-[#1C1B18]"
                    />
                  </div>
                  <button type="submit" disabled={contactStatus === 'submitting'} className="px-5 py-2.5 text-xs font-medium bg-[#1C1B18] text-[#F4F3ED] rounded">
                    {contactStatus === 'submitting' ? 'Sending...' : 'Send Message'}
                  </button>
                </form>
              )}
            </div>
          </div>
        )}

        {/* PRIVACY POLICY PAGE */}
        {activeTab === 'privacy' && (
          <div className="max-w-3xl mx-auto px-6 py-20 space-y-8 text-sm text-[#5C5A53] leading-relaxed">
            <div>
              <h1 className="text-3xl font-['EB_Garamond',serif] font-normal text-[#1C1B18] mb-2">Privacy Policy</h1>
              <p className="text-xs text-[#8C8A83]">Last updated: October 2026</p>
            </div>
            <div className="space-y-6 max-w-2xl text-[#1C1B18]">
              <div className="space-y-2">
                <h2 className="text-base font-semibold text-[#1C1B18]">Information I collect</h2>
                <p className="text-sm text-[#5C5A53]">
                  I collect only the details you submit through the contact form: your name, email address, subject, and message. I do not run analytics scripts, trackers, or marketing pixels on this site.
                </p>
              </div>
              <div className="space-y-2">
                <h2 className="text-base font-semibold text-[#1C1B18]">How I use your information</h2>
                <p className="text-sm text-[#5C5A53]">
                  I use this information solely to respond to your project inquiries and discuss potential work. I do not sell, rent, or share your contact details with anyone.
                </p>
              </div>
              <div className="space-y-2">
                <h2 className="text-base font-semibold text-[#1C1B18]">Data storage and deletion</h2>
                <p className="text-sm text-[#5C5A53]">
                  Messages are stored on a private database accessible only by me. If you want your messages or contact details removed at any time, email me at userjatin2007@gmail.com and I will delete them immediately.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* TERMS AND CONDITIONS PAGE */}
        {activeTab === 'terms' && (
          <div className="max-w-3xl mx-auto px-6 py-20 space-y-8 text-sm text-[#5C5A53] leading-relaxed">
            <div>
              <h1 className="text-3xl font-['EB_Garamond',serif] font-normal text-[#1C1B18] mb-2">Terms and Conditions</h1>
              <p className="text-xs text-[#8C8A83]">Last updated: October 2026</p>
            </div>
            <div className="space-y-6 max-w-2xl text-[#1C1B18]">
              <div className="space-y-2">
                <h2 className="text-base font-semibold text-[#1C1B18]">Working relationship</h2>
                <p className="text-sm text-[#5C5A53]">
                  I work as an independent software contractor. Before starting any project, I provide a written proposal detailing scope, timeline, and pricing. Work begins once both parties agree on these terms.
                </p>
              </div>
              <div className="space-y-2">
                <h2 className="text-base font-semibold text-[#1C1B18]">Code ownership and intellectual property</h2>
                <p className="text-sm text-[#5C5A53]">
                  Upon full payment of all agreed fees, you own the custom code, designs, and deliverables created for your project. I retain the right to reference non-confidential project work in my portfolio unless we sign a non-disclosure agreement stating otherwise.
                </p>
              </div>
              <div className="space-y-2">
                <h2 className="text-base font-semibold text-[#1C1B18]">Payment and cancellations</h2>
                <p className="text-sm text-[#5C5A53]">
                  Projects typically operate on milestone payments. If either party terminates a contract early, payment is due for work completed up to that point.
                </p>
              </div>
              <div className="space-y-2">
                <h2 className="text-base font-semibold text-[#1C1B18]">Questions</h2>
                <p className="text-sm text-[#5C5A53]">
                  If you have questions about these terms or a project proposal, email me directly at userjatin2007@gmail.com.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* ADMIN */}
        {activeTab === 'admin' && (
          <div className="max-w-3xl mx-auto px-6 py-20">
            {!adminUser ? (
              <div className="max-w-sm mx-auto p-6 rounded bg-white border border-[#E5E3D8] space-y-4">
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-[#1C1B18]" />
                  <h2 className="text-sm font-medium text-[#1C1B18]">Admin Login</h2>
                </div>
                {adminError && <div className="p-2 rounded bg-red-100 text-red-800 text-xs">{adminError}</div>}
                <form onSubmit={handleLogin} className="space-y-3">
                  <input 
                    type="email" 
                    required 
                    placeholder="userjatin2007@gmail.com" 
                    value={adminEmail} 
                    onChange={e => setAdminEmail(e.target.value)}
                    className="w-full px-3 py-2 rounded bg-[#F4F3ED] border border-[#E5E3D8] text-xs text-[#1C1B18]"
                  />
                  <input 
                    type="password" 
                    required 
                    placeholder="Password" 
                    value={adminPassword} 
                    onChange={e => setAdminPassword(e.target.value)}
                    className="w-full px-3 py-2 rounded bg-[#F4F3ED] border border-[#E5E3D8] text-xs text-[#1C1B18]"
                  />
                  <button type="submit" className="w-full py-2 text-xs font-medium bg-[#1C1B18] text-[#F4F3ED] rounded">Login</button>
                </form>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="flex justify-between items-center pb-4 border-b border-[#E5E3D8]">
                  <h1 className="text-base font-medium text-[#1C1B18]">Admin Dashboard</h1>
                  <button onClick={handleLogout} className="text-xs text-red-600 hover:underline">Sign Out</button>
                </div>
                <div className="flex gap-4 border-b border-[#E5E3D8] pb-3 text-xs">
                  <button onClick={() => setAdminView('projects')} className={`hover:text-[#1C1B18] ${adminView === 'projects' ? 'text-[#1C1B18] font-medium underline' : 'text-[#8C8A83]'}`}>Projects</button>
                  <button onClick={() => setAdminView('inquiries')} className={`hover:text-[#1C1B18] ${adminView === 'inquiries' ? 'text-[#1C1B18] font-medium underline' : 'text-[#8C8A83]'}`}>Inquiries ({inquiries.length})</button>
                </div>

                {adminView === 'projects' && (
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h3 className="text-xs font-mono uppercase text-[#8C8A83]">Projects</h3>
                      <button onClick={() => setEditingProject({ title: '', slug: '', subtitle: '', description: '', category: 'Web App', technologies: '', featured: true, sortOrder: projects.length + 1 })} className="px-3 py-1 text-xs bg-[#1C1B18] text-[#F4F3ED] rounded">Add Project</button>
                    </div>
                    {editingProject && (
                      <div className="p-4 rounded bg-white border border-[#E5E3D8] space-y-3 text-xs">
                        <input type="text" placeholder="Title" value={editingProject.title || ''} onChange={e => setEditingProject({ ...editingProject, title: e.target.value })} className="w-full px-3 py-2 bg-[#F4F3ED] border border-[#E5E3D8] rounded text-[#1C1B18]" />
                        <input type="text" placeholder="Slug" value={editingProject.slug || ''} onChange={e => setEditingProject({ ...editingProject, slug: e.target.value })} className="w-full px-3 py-2 bg-[#F4F3ED] border border-[#E5E3D8] rounded text-[#1C1B18]" />
                        <input type="text" placeholder="Subtitle" value={editingProject.subtitle || ''} onChange={e => setEditingProject({ ...editingProject, subtitle: e.target.value })} className="w-full px-3 py-2 bg-[#F4F3ED] border border-[#E5E3D8] rounded text-[#1C1B18]" />
                        <textarea placeholder="Description" rows={3} value={editingProject.description || ''} onChange={e => setEditingProject({ ...editingProject, description: e.target.value })} className="w-full px-3 py-2 bg-[#F4F3ED] border border-[#E5E3D8] rounded text-[#1C1B18]" />
                        <input type="text" placeholder="Category" value={editingProject.category || ''} onChange={e => setEditingProject({ ...editingProject, category: e.target.value })} className="w-full px-3 py-2 bg-[#F4F3ED] border border-[#E5E3D8] rounded text-[#1C1B18]" />
                        <input type="text" placeholder="Technologies" value={editingProject.technologies || ''} onChange={e => setEditingProject({ ...editingProject, technologies: e.target.value })} className="w-full px-3 py-2 bg-[#F4F3ED] border border-[#E5E3D8] rounded text-[#1C1B18]" />
                        <div className="flex justify-end gap-2">
                          <button onClick={() => setEditingProject(null)} className="px-3 py-1 bg-[#E5E3D8] rounded">Cancel</button>
                          <button onClick={async () => {
                            const method = editingProject.id ? 'PUT' : 'POST';
                            const url = editingProject.id ? `/api/projects/${editingProject.id}` : '/api/projects';
                            const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${authToken}` }, body: JSON.stringify(editingProject) });
                            if (res.ok) { setEditingProject(null); fetchPublicData(); }
                          }} className="px-3 py-1 bg-[#1C1B18] text-[#F4F3ED] rounded">Save</button>
                        </div>
                      </div>
                    )}
                    <div className="space-y-2">
                      {projects.map(p => (
                        <div key={p.id} className="p-3 rounded bg-white border border-[#E5E3D8] flex justify-between items-center text-xs">
                          <span className="font-medium text-[#1C1B18]">{p.title}</span>
                          <button onClick={async () => { if (confirm('Delete?')) { await fetch(`/api/projects/${p.id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${authToken}` } }); fetchPublicData(); }}} className="text-red-600">Delete</button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {adminView === 'inquiries' && (
                  <div className="space-y-4">
                    <h3 className="text-xs font-mono uppercase text-[#8C8A83]">Inquiries</h3>
                    {inquiries.length === 0 ? (
                      <div className="text-xs text-[#8C8A83]">No inquiries.</div>
                    ) : (
                      inquiries.map(inq => (
                        <div key={inq.id} className="p-4 rounded bg-white border border-[#E5E3D8] space-y-2 text-xs">
                          <div className="flex justify-between text-[#8C8A83]">
                            <span>{inq.name} &lt;{inq.email}&gt;</span>
                            <span>{new Date(inq.createdAt).toLocaleString()}</span>
                          </div>
                          <div className="font-medium text-[#1C1B18]">{inq.subject}</div>
                          <p className="text-[#5C5A53]">{inq.message}</p>
                          <div className="flex justify-end gap-3 pt-2">
                            <a href={`mailto:${inq.email}?subject=Re: ${inq.subject}`} className="text-[#1C1B18] underline">Reply</a>
                            <button onClick={async () => { if (confirm('Delete?')) { await fetch(`/api/inquiries/${inq.id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${authToken}` } }); fetchAdminInquiries(authToken); }}} className="text-red-600">Delete</button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-[#E5E3D8] py-12 bg-[#EFEEE6]">
        <div className="max-w-3xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between text-xs text-[#5C5A53] gap-4">
          <div>© {new Date().getFullYear()} Jatin Mehra. Available for hire.</div>
          <div>
            <a href="mailto:userjatin2007@gmail.com" className="text-[#1C1B18] hover:text-[#A03822] underline underline-offset-4 font-medium">
              userjatin2007@gmail.com
            </a>
          </div>
        </div>
      </footer>

    </div>
  );
}
